﻿using System.Collections.Generic;
using System.IO;
using System;

namespace PGUI
{
    internal class Pokemon
    {
        public Pokemon(string sor)
        {
            Nev = sor.Split(';')[0];
            Tipus = sor.Split(';')[1];
            Vedelem = int.Parse(sor.Split(';')[2]);
            Tamadas = int.Parse(sor.Split(';')[3]);
            Generacio = int.Parse(sor.Split(';')[4]);
        }

        public static List<Pokemon> PokemonokLetrehozasa(string filePath)
        {
            List<Pokemon> lista = new List<Pokemon>();
            string[] adatok = File.ReadAllLines(filePath);
            for(int i = 1; i<adatok.Length; i++)
            {
                lista.Add(new Pokemon(adatok[i]));
            }
            return lista;
        }

        public static void LegErosebb(List<Pokemon> lista)
        {
            int maxTamadas = 0;
            string champion = "";
            foreach (Pokemon p in lista)
            {
                if (p.Tamadas > maxTamadas)
                {
                    maxTamadas = p.Tamadas;
                    champion = p.Nev;
                }
            }

            Console.WriteLine($"A legerősebb pokemon a listában: {champion} ({maxTamadas}.)");
        }

        public static void AllElectric(List<Pokemon> lista)
        {
            Console.WriteLine("Az összes elektromos típusú pokemon a listában:");
            foreach (Pokemon p in lista)
            {
                if (p.Tipus == "Electric")
                {
                    Console.WriteLine(p.Nev);
                }
            }
        }

        public static void GenAvg(List<Pokemon> lista)
        {
            int sumDef = 0;
            Dictionary<int, int> genCount = new Dictionary<int, int>();
            foreach (Pokemon p in lista)
            {
                sumDef += p.Vedelem;
                if (!genCount.ContainsKey(p.Generacio))
                {
                    genCount.Add(p.Generacio, p.Vedelem);
                }
            }
            Console.WriteLine("Az összes pokemon átlagos védelme: " + ((double)sumDef / lista.Count).ToString("F2"));

            List<int> gen = new List<int>();
            foreach (Pokemon p in lista)
            {
                if (!gen.Contains(p.Generacio))
                {
                    gen.Add(p.Generacio);
                }
            }
            gen.Sort(); //kozmetika de szepen dolgozunk
            foreach (int vizsgaltGen in gen)
            {
                double genSumDef = 0;
                //double genCounter = gen.Count; atvezetheto lenne
                foreach (Pokemon p in lista)
                {
                    if (p.Generacio == vizsgaltGen)
                    {
                        genSumDef += p.Vedelem;
                    }
                }
                Console.WriteLine($"A {vizsgaltGen}. generáció átlagos védelme: {(genSumDef / lista.Count):F2}");
            }
        }

        public string Nev { get; set; }
        public string Tipus { get; set; }
        public int Vedelem { get; set; }
        public int Tamadas { get; set; }
        public int Generacio { get; set; }
    }
}