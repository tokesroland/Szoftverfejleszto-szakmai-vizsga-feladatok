﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PGUI
{
    public partial class Form1 : Form
    {
        List<Pokemon> lista;
        public Form1()
        {
            InitializeComponent();
            display.Visible = false;
            comboBox1.Visible = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Biztosan ki szeretnél lépni?", "Kijelentkezés", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                {
                    Application.Exit();
                }
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                lista = Pokemon.PokemonokLetrehozasa(fd.FileName);
                display.Visible = true;
                comboBox1.Visible = true;
                display.DataSource = lista;
                List<string> tipusok = new List<string>();

                foreach (Pokemon p in lista)
                {
                    if (!tipusok.Contains(p.Tipus))
                    {
                        tipusok.Add(p.Tipus);
                    }
                }
                comboBox1.DataSource = tipusok;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string kivalasztott = comboBox1.GetItemText(comboBox1.SelectedItem);
            List<Pokemon> szurt = new List<Pokemon>();
            foreach (Pokemon p in lista)
            {
                if (!szurt.Contains(p) && p.Tipus == kivalasztott)
                {
                    szurt.Add(p);
                }
            }
            display.DataSource = szurt;
        }

        private void display_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (display.Rows.Count > 0)
            {
                Pokemon kivalasztottPokemon = (Pokemon)display.CurrentRow.DataBoundItem;
                label1.Text = $"Név: {kivalasztottPokemon.Nev}\n" +
                    $"Típus: {kivalasztottPokemon.Tipus}\n" +
                    $"Támadás: {kivalasztottPokemon.Tamadas}\n" +
                    $"Védekezés: {kivalasztottPokemon.Vedelem}\n" +
                    $"Generáció: {kivalasztottPokemon.Generacio}";

                pictureBox1.ImageLocation = $"https://img.pokemondb.net/artwork/large/{kivalasztottPokemon.Nev.ToLower()}.jpg";
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
